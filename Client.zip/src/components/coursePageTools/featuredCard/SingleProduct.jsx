

const SingleProduct = () => {
    return (
        <div>


        </div>
    )
}

export default SingleProduct